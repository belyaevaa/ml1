#include "rect.h"
#include <QPainter>

Rect::Rect()

{

}

Rect::Rect(int x1, int y1, int x2, int y2)
{
    x=x1 < x2 ? (w = x2 - x1) : (w = x1 - x2);
    y=y1 < y2 ? (h = y2 - y1) : (h = y1 - y2);
}

bool Rect::contains(int x, int y)
{
    return(x >= this->x && x<= (this->x+w) && y>= this->y && y<= (this->y+h));
}

void Rect::draw(QPainter *painter)
{
    painter->drawRect(x, y, w, h);
}

